# Revised mathematical writing

Based on Chenrui Xu's Edinburgh coursework; revised 25 September 2026 with AI-assisted mathematical and editorial checking. These are expository notes, not new research theorems. The source/revision passages identify historical material and new elaboration.

Build each note from this directory using `pdflatex analysis.tex`, `pdflatex numerics.tex`, or `pdflatex cubic.tex` (run twice for references). Standard TeX Live packages are used. Exact algebra checks require Python and SymPy 1.14: `python verify_cubic.py` and `python verify_numerics.py`. Logical proofs remain necessary; symbolic checks do not replace them.

Original assignments and personal student identifiers are not included. The original cubic report's exact submission date is unconfirmed; the archive places it in 2021-2022. The analysis and numerical ODE assignments date to February-March 2023.
