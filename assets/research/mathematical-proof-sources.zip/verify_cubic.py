"""Exact algebra checks for the revised ED07 note; requires SymPy 1.14."""
import sympy as s

x, y, z, lam, w, k = s.symbols('x y z lam w k')
F = x**3 + y**3 + z**3 + lam*x*y*z
H = s.det(s.hessian(F, (x, y, z)))
assert s.expand(H - ((216 + 2*lam**3)*x*y*z - 6*lam**2*(x**3+y**3+z**3))) == 0
assert s.expand(H + 6*lam**2*F - 8*(27+lam**3)*x*y*z) == 0
assert s.expand(F.subs(y, -x+lam*z/3) - (1+lam**3/27)*z**3) == 0

points = []
for j in range(3):
    points.extend([(1, -w**j, 0), (1, 0, -w**j), (0, 1, -w**j)])
for point in points:
    for expression in (F, H):
        value = s.expand(expression.subs(dict(zip((x, y, z), point)), simultaneous=True))
        assert s.rem(value, w**2+w+1, w) == 0

# k**(-1)=k**2 for k**3=1; use the polynomial representative.
singular = {x: 1, y: 1, z: k**2, lam: -3*k}
for expression in (F, *(s.diff(F, v) for v in (x, y, z))):
    value = s.expand(expression.subs(singular, simultaneous=True))
    assert s.rem(value, k**3-1, k) == 0
print('PASS: Hessian, restriction, tangent identity, nine flexes, singular family.')
