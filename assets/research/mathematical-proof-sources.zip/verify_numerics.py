"""Independent algebra checks for the revised coursework statements."""
import json
import sympy as s

h, t, gamma, z, omega = s.symbols('h t gamma z omega', real=True)

def residual(y):
    return s.expand(y.subs(t,t+2*h)-s.Rational(4,3)*y.subs(t,t+h)
                    +s.Rational(1,3)*y-h*gamma*s.diff(y,t).subs(t,t+h))

linear = s.factor(residual(t))
quadratic = s.factor(residual(t**2).subs(gamma,s.Rational(2,3)))
assert s.simplify(linear-h*(s.Rational(2,3)-gamma)) == 0
assert quadratic == s.Rational(4,3)*h**2
assert s.simplify(linear.subs(gamma,s.Rational(4,3))) == -s.Rational(2,3)*h

rho = z**2-s.Rational(4,3)*z+s.Rational(1,3)
assert s.factor(rho) == (z-1)*(3*z-1)/3
R = 1+z+z**2/2
imag_modulus_squared = s.expand(R.subs(z,s.I*omega)*R.subs(z,-s.I*omega))
assert imag_modulus_squared == 1+omega**4/4

# With h^2=1/5, the first exact zero must be u_6, not u_5.
u = s.Integer(1)
values = [u]
for n in range(8):
    u *= 1-s.Rational(n,5)
    values.append(s.factor(u))
assert values[5] != 0 and values[6:] == [0,0,0]

checks = {
    'multistep_linear_residual': str(linear),
    'quadratic_residual_at_consistent_gamma': str(quadratic),
    'claimed_gamma_4_over_3_fails_linear_test': str(linear.subs(gamma,s.Rational(4,3))),
    'multistep_characteristic_roots': [str(x) for x in s.solve(rho,z)],
    'rk2_imaginary_modulus_squared': str(imag_modulus_squared),
    'euler_h_squared_one_fifth_values': [str(v) for v in values],
    'all_exact_checks_passed': True,
}
print(json.dumps(checks, indent=2))
